<?php
namespace CloudStorage\Mail;
class Mailer{
    
}