<?php
class Image implements ImageInterface{
    function getDimension(){
        return "100x100";
    }
}