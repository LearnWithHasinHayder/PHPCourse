<?php
namespace CloudStorage\FileSystem\Contracts;
interface Image{
    function getDimension();
}