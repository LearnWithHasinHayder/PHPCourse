<?php
namespace CloudStorage\FileSystem;
class Scanner{
    
}