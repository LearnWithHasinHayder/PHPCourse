<?php
namespace CloudStorage;
spl_autoload_register(function($name){
    echo $name;
});

class Main{
    function __construct(){
        new Mail\Mailer();
    }
}

new Main();